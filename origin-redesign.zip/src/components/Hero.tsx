const notes = [
  { t: 'Which broker covers Brazil??', c: 'bg-amber text-ink', p: 'left-[4%] top-[26%]', r: '-8deg' },
  { t: 'Poland parental leave (PDF, in Polish)', c: 'bg-lime text-ink', p: 'right-[5%] top-[24%]', r: '6deg' },
  { t: 'Renewal deadline… was it Friday?', c: 'bg-mint text-ink', p: 'left-[8%] bottom-[16%]', r: '5deg' },
  { t: 'Who signed off this commission?', c: 'bg-white text-ink', p: 'right-[7%] bottom-[20%]', r: '-6deg' },
]

export default function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-b from-blue via-navy to-ink px-6 pt-32 pb-24 text-center">
      <div className="absolute -right-40 top-10 h-[620px] w-[620px] rounded-full bg-teal/40 blur-3xl" />
      <div className="absolute -left-52 top-1/3 h-[520px] w-[520px] rounded-full border border-mint/30" />
      {notes.map((n) => (
        <div key={n.t} style={{ ['--r' as string]: n.r }} className={`absolute hidden max-w-[190px] animate-float rounded-md p-4 font-hand text-2xl leading-tight shadow-2xl lg:block ${n.c} ${n.p}`}>
          {n.t}
        </div>
      ))}
      <div className="relative max-w-4xl">
        <p className="animate-rise text-sm font-bold uppercase tracking-[0.25em] text-mint">A story about benefits</p>
        <h1 className="mt-6 animate-rise text-5xl font-bold leading-[1.02] tracking-tight [animation-delay:.1s] md:text-8xl">
          Meet Priya.<br /><span className="text-mint">43 countries.</span><br />One very long Monday.
        </h1>
        <p className="mx-auto mt-8 max-w-2xl animate-rise text-lg text-white/75 [animation-delay:.2s] md:text-xl">
          Benefits are your second-biggest people cost, and most teams are running them in the dark. Follow Priya through one week with Origin™, the world's first Enterprise Benefits Intelligence platform.
        </p>
        <div className="mt-10 flex animate-rise flex-wrap justify-center gap-4 [animation-delay:.3s]">
          <a href="#how" className="rounded-full bg-mint px-8 py-4 font-bold text-ink transition hover:scale-105 hover:shadow-[0_0_50px_-5px] hover:shadow-mint">Meet your benefits team's new best friend ↗</a>
          <a href="#contact" className="rounded-full border border-amber px-8 py-4 font-bold text-mint transition hover:bg-amber/10">Let's have a chat! ↗</a>
        </div>
      </div>
    </section>
  )
}
